DSN name : hrms
path : http://localhost:8080/servlet/admins1